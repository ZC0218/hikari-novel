package pers.cyh128.hikari_novel

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
