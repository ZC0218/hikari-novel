enum Language {
  simplifiedChinese,
  traditionalChinese,
  followSystem;
}