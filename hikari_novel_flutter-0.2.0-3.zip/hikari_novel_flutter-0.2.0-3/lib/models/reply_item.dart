class ReplyItem {
  final String content;
  final String userName;
  final String uid;
  final String time;

  ReplyItem({required this.content, required this.userName, required this.uid, required this.time});
}