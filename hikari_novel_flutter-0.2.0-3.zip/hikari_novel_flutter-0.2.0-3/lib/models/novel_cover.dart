class NovelCover {
  NovelCover(this.title, this.imageUrl, this.aid);

  final String title;
  final String? imageUrl;
  final String aid;
}