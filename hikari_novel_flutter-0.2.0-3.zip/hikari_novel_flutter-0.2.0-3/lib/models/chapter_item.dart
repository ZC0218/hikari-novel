class ChapterItem {
  final String text;
  final List<String>? image;

  const ChapterItem({required this.text, this.image});
}