class BrowsingHistory {
  final String aid;
  final String title;
  final String img;
  final DateTime time;

  BrowsingHistory({required this.aid, required this.title, required this.img, required this.time});
}
