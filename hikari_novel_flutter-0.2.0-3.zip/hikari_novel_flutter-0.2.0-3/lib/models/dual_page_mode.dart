enum DualPageMode {
  auto,
  enabled,
  disabled
}