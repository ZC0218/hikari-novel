enum ReaderDirection {
  leftToRight, rightToLeft, upToDown
}