// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cat_chapter.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CatChapter _$CatChapterFromJson(Map<String, dynamic> json) =>
    CatChapter(title: json['title'] as String, cid: json['cid'] as String);

Map<String, dynamic> _$CatChapterToJson(CatChapter instance) =>
    <String, dynamic>{'title': instance.title, 'cid': instance.cid};
