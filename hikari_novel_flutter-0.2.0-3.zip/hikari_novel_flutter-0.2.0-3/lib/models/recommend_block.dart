import 'package:hikari_novel_flutter/models/novel_cover.dart';

class RecommendBlock {
  final String title;
  final List<NovelCover> list;

  RecommendBlock(this.title, this.list);
}