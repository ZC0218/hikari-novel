enum PageState {
  loading,
  success,
  empty,
  error,
  pleaseSelect,
  jumpToOtherPage,
  inFiveSecond,
  bookshelfContent,
  bookshelfSearch,
  placeholder
}