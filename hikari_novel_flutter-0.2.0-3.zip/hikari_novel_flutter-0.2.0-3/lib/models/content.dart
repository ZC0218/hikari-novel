class Content {
  final String text;
  final List<String> images;

  Content({required this.text, required this.images});
}
